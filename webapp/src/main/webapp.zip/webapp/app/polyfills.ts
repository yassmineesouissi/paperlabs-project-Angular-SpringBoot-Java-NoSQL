import 'core-js/proposals/reflect-metadata';
import 'zone.js/dist/zone';
import 'hammerjs';

require('../manifest.webapp');
