import { ValueConstraints } from 'app/entities/ValueConstraints';

export class Workflow {
  inputId: string;
  valuesConstraints: ValueConstraints[];
}
