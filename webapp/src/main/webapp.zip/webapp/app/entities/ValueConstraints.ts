import { Constraint } from 'app/entities/Constraint';

export class ValueConstraints {
  value: string;
  constraints: Constraint[];
}
