export class Step {
  id: string;
  title: string;
  description: string;
  visibility: boolean;
  blocs: string[];
}
