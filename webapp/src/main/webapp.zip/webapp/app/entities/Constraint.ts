export class Constraint {
  elementId: string;
  visibility: boolean;
}
