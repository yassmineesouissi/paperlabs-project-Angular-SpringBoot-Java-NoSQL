export class Bloc {
  id: string;
  title: string;
  description: string;
  help: string;
  visibility: boolean;
  inputs: string[];
}
