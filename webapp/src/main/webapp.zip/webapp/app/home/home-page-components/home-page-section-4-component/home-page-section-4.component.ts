import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-home-page-section-4',
  templateUrl: './home-page-section-4.component.html',
  styleUrls: ['home-page-section-4.scss']
})
export class HomePageSection4Component implements OnInit {
  constructor() {}

  ngOnInit() {}
}
