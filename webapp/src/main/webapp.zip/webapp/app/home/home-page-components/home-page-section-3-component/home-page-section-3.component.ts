import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-home-page-section-3',
  templateUrl: './home-page-section-3.component.html',
  styleUrls: ['home-page-section-3.scss']
})
export class HomePageSection3Component implements OnInit {
  constructor() {}

  ngOnInit() {}
}
