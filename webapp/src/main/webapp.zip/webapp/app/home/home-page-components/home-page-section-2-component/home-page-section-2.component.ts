import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-home-page-section-2',
  templateUrl: './home-page-section-2.component.html',
  styleUrls: ['home-page-section-2.scss']
})
export class HomePageSection2Component implements OnInit {
  constructor() {}

  ngOnInit() {}
}
