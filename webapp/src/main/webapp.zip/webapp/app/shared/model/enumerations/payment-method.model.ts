export const enum PaymentMethod {
  MOBICACH = 'MOBICACH',
  EDINAR = 'EDINAR'
}
