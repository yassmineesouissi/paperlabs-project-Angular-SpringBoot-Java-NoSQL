export const enum OrderStatus {
  WAITING = 'WAITING',
  PAID = 'PAID',
  ABANDONED = 'ABANDONED'
}
